#!/usr/bin/env python
# -*- coding: utf-8 -*-

# These colours, having these defaults, could be configurable,
# through command line options or configuration file.
LINE_COLOUR = 'x'
FILL_COLOUR = ' '

def is_line_horizontal( x1, y1, x2, y2 ) :
  return y1 == y2 if x1 and y1 and x2 and y2 else False

def is_line_vertical( x1, y1, x2, y2 ) :
  return x1 == x2 if x1 and y1 and x2 and y2 else False

def draw_line( rows, x1, y1, x2, y2, line_colour = LINE_COLOUR ) :
  """
    Makes sure that given pixels correspond either to
    an horizontal line or to a vertical line.

    This aids the loop logic: since only one of the coordinates changes
    then it's just a matter of looping rows and then columns to
    set the pixels to the given colour.
  """
  is_horizontal = is_line_horizontal ( x1, y1, x2, y2 )
  is_vertical   = is_line_vertical   ( x1, y1, x2, y2 )

  if is_horizontal or is_vertical :
    if x1 > 0 and y1 > 0 and rows :
      first_row = rows[ 0 ]
      maximum_x = len( first_row ) - 1
      maximum_y = len( rows      ) - 1

      for y in range( y1, min( y2 + 1, maximum_y ) ) :
        for x in range( x1, min( x2 + 1, maximum_x ) ) :
          rows[ y ][ x ] = line_colour

  return rows

def draw_rectangle( rows, x1, y1, x2, y2, fill_colour = FILL_COLOUR ) :
  """
    It depends on draw_line() to draw as many lines as the rectangle takes.
    The first and last lines have all pixels with line colour,
    while the others have pixels, at start and at the end, in line colour
    and all other pixels in the given fill colour.
  """
  if x1 > 0 and y1 > 0 and rows :
    first_row = rows[ 0 ]
    maximum_x = len( first_row ) - 1
    maximum_y = len( rows      ) - 1

    for y in range( y1, min( y2 + 1, maximum_y ) ) :
      if y in ( y1, y2 ) :
        rows = draw_line( rows, x1, y, x2, y )
      else :
        rows = draw_line( rows, x1, y, x2, y )
        rows = draw_line( rows, x1 + 1, y, x2 - 1, y, fill_colour )

  return rows

if __name__ == '__main__' :

  import doctest
  doctest.testmod()
