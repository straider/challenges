#!/usr/bin/env python
# -*- coding: utf-8 -*-

import layer

width  = None
height = None
layers = list()

def is_initialized() :
  return len( layers ) >  0

def reset() :
  global width, height, layers
  width  = None
  height = None
  layers = list()

def initialize( new_width, new_height ) :
  global width, height, layers

  if new_width > 0 and new_height > 0 :
    reset()
    width     = new_width
    height    = new_height
    new_layer = layer.create( width, height )
    add_layer( new_layer )

  return len( layers ) > 0

def add_layer( new_layer ) :
  if width and height :
    layers.append( new_layer )
    return True
  else :
    return False

def merge_layers() :
  merged_layer = layers[ 0 ]

  for layer_position in range( 1, len( layers ) ) :
    current_layer = layers[ layer_position ]
    merged_layer  = layer.merge( merged_layer, current_layer )

  return merged_layer

def repaint() :
  lines = list()

  if is_initialized() :
    merged_layer = merge_layers()

    lines = layer.paint( merged_layer )

  return lines

def fill( x, y, colour ) :
  """
    Fills every nearby pixel of given pixel with given colour,
    by merging all layers in canvas into one layer, to validate
    that pixel current colour is not line colour ( foreground ).

    If so, then it collects all nearby pixels with same colour,
    and for each one changes the colour to the given colour.
    Since the layer has changed it then clears the canvas and
    adds the changed layer as the first layer to canvas.
  """
  global layers

  if is_initialized() :
    merged_layer    = merge_layers()
    previous_colour = layer.get_colour( merged_layer, x, y )

    if layer.is_foreground_colour( previous_colour ) :
      return
    else :
      changed_layer = merged_layer

      pixels = layer.collect_pixels( merged_layer, x, y, previous_colour )
      if pixels :
        for pixel in pixels :
          pixel_x = pixel[ 0 ]
          pixel_y = pixel[ 1 ]
          changed_layer = layer.mark_pixel( changed_layer, pixel_x, pixel_y, colour )

        layers = list()
        add_layer( changed_layer )

if __name__ == '__main__' :

  import doctest
  doctest.testmod()
