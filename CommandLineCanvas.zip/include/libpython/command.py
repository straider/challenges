#!/usr/bin/env python
# -*- coding: utf-8 -*-

import shape
import layer
import canvas

COMMANDS = { 'C' : 2
           , 'L' : 4
           , 'R' : 4
           , 'B' : 3
           , 'Q' : 0
           }

def get_input() :
  letter    = None
  arguments = None

  is_input_valid = False
  while not is_input_valid :
    input = raw_input( 'enter command: ' )

    if len( input ) >= 1 :
      input_components = input.split()
      letter           = input_components[ 0 ].upper()
      arguments        = input_components[ 1 : ]

      is_input_valid = is_valid( letter, arguments )
      if not is_input_valid :
        if letter in COMMANDS.keys() :
          print 'Invalid command, please check the arguments!'
        else :
          print 'Unknown command!'

  return ( letter, arguments )

def is_valid( letter, arguments ) :
  result = False
  if type( letter ) is str :
    uppercase_letter = letter[ 0 ].upper()

    is_letter_a_command = ( uppercase_letter in COMMANDS.keys() )
    if is_letter_a_command :
      number_of_expected_arguments  = COMMANDS[ uppercase_letter ]
      has_right_number_of_arguments = True
      if number_of_expected_arguments != 0 :
        has_right_number_of_arguments = len( arguments ) == number_of_expected_arguments if arguments else False

      result = is_letter_a_command and has_right_number_of_arguments

  return result

def reset_canvas() :
  canvas.reset()

def create_canvas( width, height ) :
  result = False

  if width and height :
    result = canvas.initialize( int( width ), int( height ) )

  return result

def show_canvas() :
  lines = canvas.repaint()
  for line in lines :
    print line

  return lines

def add_line_shape( x1, y1, x2, y2 ) :
  result = False

  if canvas.is_initialized() :
    clean_layer = layer.create( canvas.width, canvas.height )
    drawn_layer = shape.draw_line( clean_layer, int( x1 ), int( y1 ), int( x2 ), int( y2 ) )
    result      = canvas.add_layer( drawn_layer )

  return result

def add_rectangle_shape( x1, y1, x2, y2 ) :
  result = False

  if canvas.is_initialized() :
    clean_layer = layer.create( canvas.width, canvas.height )
    drawn_layer = shape.draw_rectangle( clean_layer, int( x1 ), int( y1 ), int( x2 ), int( y2 ) )
    result      = canvas.add_layer( drawn_layer )

  return result

def fill( x, y, colour ) :
  result = False

  if canvas.is_initialized() :
    canvas.fill( int( x ), int( y ), colour )
    result = True

  return result

def quit() :
  return None

ACTIONS = { 'C' : create_canvas
          , 'L' : add_line_shape
          , 'R' : add_rectangle_shape
          , 'B' : fill
          , 'Q' : quit
          }

def execute_action( action, arguments ) :
  result = False

  function = ACTIONS.get( action.upper() )
  if function :
    if arguments :
      result = function( *arguments ) # Unpack the arguments.
    else :
      result = function()

  if result :
    show_canvas()
  elif result is None :
    result = True

  return result

if __name__ == '__main__' :

  import doctest
  doctest.testmod()
