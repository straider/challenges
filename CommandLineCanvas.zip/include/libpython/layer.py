#!/usr/bin/env python
# -*- coding: utf-8 -*-

import copy

TRANSPARENT_COLOUR = ''
BACKGROUND_COLOUR  = ' '
FOREGROUND_COLOUR  = 'x'

def create( width, height ) :
  if width > 0 and height > 0 :
    first_row = [ '-' for _ in range( width + 2 ) ]
    last_row  = [ '-' for _ in range( width + 2 ) ]

    rows = list()
    rows.append( first_row )
    for _ in range( height ) :
      row         = [ '|', [ TRANSPARENT_COLOUR for _ in range( width ) ],'|' ]
      flatten_row = [ item for items in row for item in items ]
      rows.append( flatten_row )
    rows.append( last_row )

    return rows
  else :
    return None

def paint( rows ) :
  lines = list()

  if rows :
    for row in rows :
      paintable_row = [ item if item != TRANSPARENT_COLOUR else BACKGROUND_COLOUR for item in row ]

      line = ''.join( paintable_row )
      lines.append( line )

  return lines

def merge( lower_rows, upper_rows ) :
  number_of_rows = len( lower_rows ) # Should check that both lower and upper layers have same dimensions.

  rows = list()

  # Optimization: bypass first and last row, always use upper layer for these rows.
  for row_index in range( number_of_rows ) :
    lower_row = lower_rows[ row_index ]
    upper_row = upper_rows[ row_index ]

    zipped_row = zip( lower_row, upper_row )

    merged_row = [ items[ 0 ] if items[ 1 ] == TRANSPARENT_COLOUR else items[ 1 ] for items in zipped_row ]
    rows.append( merged_row )

  return rows

def get_colour( rows, x, y ) :
  colour = None

  if rows :
    first_row = rows[ 0 ]
    range_x   = range( len( first_row ) )
    range_y   = range( len( rows      ) )

    if x in range_x and y in range_y :
      colour = rows[ y ][ x ]

  return colour

def is_foreground_colour( colour ) :
  return colour == FOREGROUND_COLOUR

def mark_pixel( rows, x, y, colour ) :
  changed_rows = None

  if rows :
    changed_rows = copy.deepcopy( rows )

    first_row = changed_rows[ 0 ]
    range_x   = range( 1, len( first_row    ) - 1 )
    range_y   = range( 1, len( changed_rows ) - 1 )

    if x in range_x and y in range_y and colour is not None :
      changed_rows[ y ][ x ] = colour

  return changed_rows

def get_all_pixels( rows, colour ) :
  """
    Given a layer - collection of rows - it then
    walks every row and its pixels to build a set
    of the pixels that have the given colour.

    This is an auxiliary function, not design at start.
  """
  pixels = None

  if rows :
    pixels = set()
    for y, row in enumerate( rows ) :
      for x, pixel_colour in enumerate( row ) :
        if pixel_colour == colour :
          pixels.add( ( x, y ) )

  return pixels

def collect_pixels( rows, x, y, colour ) :
  """
    Given a layer - collection of rows - and a pixel
    it then collects every other nearby pixel with the
    same colour.
  """
  pixels = None

  if rows :
    first_row = rows[ 0 ]
    range_x   = range( 1, len( first_row ) - 1 )
    range_y   = range( 1, len( rows      ) - 1 )

    if x in range_x and y in range_y and colour is not None :
      """
        - Starts by building a set of all pixels that have the given colour;
        - Initializes 2 sets:
          - One with all the pixels found nearby to return: pixels_set
          - Another with temporary nearby pixels, changed at every iteration: nearby_pixels_with_same_colour
        - Loops the entire set of pixels, which decreases one pixel at every iteration
          until there are no more nearby pixels with the same colour.
      """
      all_pixels = get_all_pixels( rows, colour )
      pixels_set = set()

      nearby_pixels_with_same_colour = set()

      pixel = ( x, y )

      is_hit = pixel in all_pixels
      while len( all_pixels ) > 0 and is_hit :
        if is_hit and pixel :
          all_pixels.remove( pixel )
          pixels_set.add( pixel )

          # Builds set with nearby pixels for the current pixel.
          pixel_x = pixel[ 0 ]
          pixel_y = pixel[ 1 ]

          left_pixel    = ( pixel_x - 1, pixel_y     )
          right_pixel   = ( pixel_x + 1, pixel_y     )
          top_pixel     = ( pixel_x    , pixel_y - 1 )
          bottom_pixel  = ( pixel_x    , pixel_y + 1 )
          nearby_pixels = set( [ left_pixel, right_pixel, top_pixel, bottom_pixel ] )

          """
            Intersects current set of nearby pixels for current pixel
            with every pixel still left in the set of all pixels with same colour
            and joins ( union ) with leftover nearby pixels from previous iterations.
          """
          nearby_pixels_with_same_colour = nearby_pixels & all_pixels | nearby_pixels_with_same_colour

          pixel  = nearby_pixels_with_same_colour.pop() if len( nearby_pixels_with_same_colour ) > 0 else None
          is_hit = pixel is not None

      pixels = sorted( pixels_set )

  return pixels

if __name__ == '__main__' :

  import doctest
  doctest.testmod()
