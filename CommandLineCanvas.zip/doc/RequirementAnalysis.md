:: Springer Nature Challenge ::
===============================

# 2. Requirement Analysis

## 2.1. User Requirements

- Write a simple console version of a drawing program;
- Drawing on the canvas by issuing various commands:
    - ```C w h```: create a new canvas of width **w** and height **h**;
    - ```L x1 y1 x2 y2```: create a new line from ( x1, y1 ) to ( x2, y2 );
    - ```R x1 y1 x2 y2```: create a new rectangle, whose upper left corner is ( x1, y1 ) and lower right corner is ( x2, y2 );
    - ```B x y c```: fill the entire area connected to ( x, y ) with _colour_ **c**.
- Until command is ```Q``` to quit;
- User input is prefixed with ```enter command: ```.

## 2.2. Functional Requirements

- Program is a REPL: Read-Eval-Print Loop, until quit command is issued;
- Canvas is a collection of layers;
- Layer is a collection of rows and row is a collection of pixels;
- Pixels can have 1 of 4 colours:
    - '': transparent;
    - ' ': rectangle initial fill colour;
    - 'x': line ( foreground ) colour;
    - c: fill ( background ) colour.
- Shapes are lines or rectangles;
- Each new shape adds an extra layer on top of previous layers.

**Note**: layers help to cope with filling an area without flooding shapes.

## 2.3. Technical Requirements

- Free to write solution in any programming language;
- Avoid 3rd party libraries;
- Don't over-engineer the solution ( KISS, YAGNI, DRY );
- Prepared to extend the functionality in the near future;
- Must use VCS ( Git or Mercurial ) in LocalRepository Mode ( private ).
