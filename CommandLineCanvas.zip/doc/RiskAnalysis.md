:: Springer Nature Challenge ::
===============================

# 3. Risk Analysis

## 3.1. Out of Scope

- Memory concerns? CPU load concerns? Performance concerns?
- Possible change requests to extend functionality?
    - Save / Load canvas ( drawing );
    - Set different transparent, line and solid colours;
    - Drag shape;
    - Resize shape;
    - Delete shape;
    - Undo command ( except quit, save, load );
    - Support diagonal lines? Will allow triangle or trapezoidal shapes;
    - Support curved lines? Will allow ellipsis ( and circles ).
- [curses](https://docs.python.org/2/library/curses.html) would be more suitable ( TUI vs CLI )?

## 3.2. Technical Decisions

The more complex requirement to solve in this challenge is how to properly perform a bucket fill action. Although programs, such as Windows Paint, also fill areas defined by lines. It's just for closed shapes that bucket fill action does not spill over areas outside the shape.

I decided to simplify and perform the fill action as a swap colours mechanism, dealing with layers ( where each shape has its own layer ). This works fine for most cases, except that it fills areas in distinct shapes that have the same colour and does not work has the example in the problem statement.

To solve this I later decided to use a recursive function that marks each pixel and moves onto the pixels around ( left, right, top, bottom ) if their colour does not match line colour.

I've also identified other risks, which have much lower priority:

- Should raise exceptions instead of working with **None** values?
    - Usually, exceptions are for when an unexpected or unknown event occurs and the system is no longer in conditions for code to proceed;
    - It's a common practice to work with functions that always return a value, even if it is sometimes Null ( or Nil or None ).
- Should validate that layers have same dimensions as canvas?
- Are there any side-effects that can cause layers to resize?
- Are there any side-effects that can cause margins to be overwritten?
- Should validate number of arguments of each command?
    - Later on there may be more arguments, optional.
