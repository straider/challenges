:: Springer Nature Challenge ::
===============================

# 4. Technical Design

## 4.1. Scope

This is a coding assignment for a job where its specification states the following expectations:
- Considered a generalist and can pick the right tool for the job;
- Keep up to date with technology trends and believe in life-long learning;
- Have a strong problem-solving mindset;
- Passionate in work and love to share ideas with others;
- Experienced in popular OO languages;
- Embrace agile, XP, and Continuous Delivery;
- ~~Understand how to build large-scale web applications~~; Eager to learn how to build large-scale applications;
- Enjoy working in *nix environments.

## 4.2. Constraints / Limitations / Assumptions

- Only supports horizontal and vertical lines;
- Fill colour must be in ranges 0..9 or a..z;
- Accept lowercase or uppercase one-letter commands;
- Command arguments separator is whitespace;
- Unknown commands trigger an error message: "Unknown command!";
- Invalid commands ( wrong options ) trigger an error message: "Invalid command, please check the arguments!";
- Internationalization ( i18n ) or Localization ( l10n ) is out of scope;
- Transparent, line colour and solid fill are static ( constants ).

## 4.3. Design Choices

- Why **Python**? Because:
    - Has good collections support in its standard library: lists, sets, dictionaries;
    - Has good string handling functions;
    - Has slicing facilities for collections and strings;
    - Has doctest and unittest modules;
    - Although is handles exceptions it also has a good enough type: NoneType;
    - Good input function ( Perl and Ruby, as an example, require chomp after reading input );
    - Has REPL, which is useful for prototyping and learning;
    - It would be good to have switch statement, although one should read the article [Why Doesn't Python Have Switch/Case?](http://www.pydanny.com/why-doesnt-python-have-switch-case.html).
- Why solving by applying **procedural** programming paradigm instead of applying an **object-oriented** or **functional** paradigm?
    - The problem statement recommends not to over-engineer the solution ( KISS );
    - Although, in preparation for future functionality expansion, it would probably be better to apply object-oriented paradigm ( DRY );
    - But since it's a CommandLine program it will be enough for now ( YAGNI ).
- Why solving by following the **TDD Rhythm** - Red-Green-Refactor?
    - Helps to surface simple, clean and faster entities design;
    - I consider it a technical requirement, being a Software Craftsman, and helps to avoid regressions and minimizes bugs when new features are implemented;
    - I consider to be a best practice to commit on each step of the TDD Rhythm: Red and commit test cases; Green and commit test cases solution; Refactor if needed and commit;
    - Is even better when, in case of need, one can mock some features ( such as user input ).
- Why working with layers?
    - Because it simplifies fill logic. Each shape is on its own layer and only at presentation time are the layers merged together in a coherent way.
- Why coding fill logic as swap colours mechanism?
    - Because it works just like Windows Paint does and it's a simple mechanism to build on top of layering.

**Note**: the unit test module selected to support TDD, in this case, is **unittest**, instead of **doctest** because it's easier to disable output when executing test cases.

## 4.4. Modules

### 4.4.1. Canvas

#### 4.4.1.1. Attributes

- canvas ```width```;
- canvas ```height```;
- list of ```layers```, which is an ordered collection where first layer is the bottom layer and the last layer is the top layer.

#### 4.4.1.2. Responsibilities

- ```is_initialized()```: returns true if the canvas has been initialized ( has at least one layer ), false otherwise;
- ```reset()```: restores canvas to pristine condition;
- ```initialize( width, height )```: initializes canvas with a width and height, both are positive numbers ( greater than zero ) and adds a layer filled with transparent colour;
- ```add_layer( layer )```: adds the given layer to the canvas list of layers, only if the canvas is initialized ( has width and height );
- ```merge_layers()```: merges all layers into one layer, delegating on layer.merge();
- ```repaint()```: iterates through the list of layers, by merging them together, from bottom to top and prints to the standard output;
- ~~```flood( x, y, colour )```: fills an area around point ( x, y ) with given colour;~~
    - If is first layer than set every _pixel_ to given colour;
    - If it's not first layer than it contains a shape and so just fill the shape if is a hit:
        - pixel at point ( x, y ) has other colour than line colour;
        - if so, replace all pixels in that colour with given colour.
    - Start by top level layer and stop as soon as a shape is hit and filled: replace previous fill colour with new fill colour;
    - If no shape is hit then fill first layer.
- ```fill( x, y, colour )```: fills an area with a colour, starting at a given pixel and spreading to every nearby pixel with same colour:
    - Starts by merging all layers;
    - If the colour of the given pixel is not line colour then collect all nearby pixels with same colour as that pixel;
    - For each collected pixel then set its colour to the given colour;
    - Clears canvas layers and adds filled layer as first layer of canvas.

**Note**: an uninitialized canvas prints nothing to the standard output.

### 4.4.2. Layer

#### 4.4.2.1. Attributes

N/A.

#### 4.4.1.2. Responsibilities

- ```create( width, height )```: returns a list of rows, given a width and height when both are positive numbers ( greater than zero ), where number of rows matches given height and number of pixels in each row matches given width. It also fills rows with margins and transparent colour;
- ```paint( rows )```: returns a list of lines, for output, by converting each row of the given layer to its "printable" format;
- ```merge( lower_rows, upper_rows )```: merge rows of lower layer with rows of upper layer, by applying these rules row by row, and return merged rows:
  - If pixel is transparent use lower row pixel colour;
  - If not then use upper row pixel colour.
- ```get_colour( rows, x, y )```: returns colour at pixel ( x, y ) in given rows;
- ```is_foreground_colour( colour )```: returns true if colour matches foreground colour;
- ~~```is_transparent_colour( colour )```: returns true if colour matches transparent colour;~~
- ```mark_pixel( rows, x, y, colour )```: set the colour at pixel ( x, y ) in the given rows;
- ```get_all_pixels( rows, colour )```: returns a set ( unique pixels ) that have a given colour;
- ```collect_pixels( rows, x, y, colour )```: given a layer ( collection of rows ) and a colour it the collects all nearby pixels having same colour;
- ~~```replace_colour( rows, old_colour, new_colour )```: changes all pixels having old colour to new colour and returns changed rows.~~

**Note**: having foreground colour as a constant of layer prevents configuring other colours, by command line options or configuration files.

**Attention**: the logic of replace_colour() resembles a swap colour feature in image programs and may cause areas to be filled when they shouldn't.

### 4.4.3. Shape

#### 4.4.3.1. Attributes

N/A.

#### 4.4.3.2. Responsibilities

- ```is_line_horizontal( x1, y1, x2, y2 )```: returns true if y1 matches y2;
- ```is_line_vertical( x1, y1, x2, y2 )```: returns true if x1 matches x2;
- ```draw_line( layer, x1, y1, x2, y2 )```: returns a layer where an horizontal or vertical line has been drawn, from pixel at ( x1, y1 ) to pixel at ( x2, y2 );
- ```draw_rectangle( layer, x1, y1, x2, y2 )```: returns a layer where a rectangle has been drawn, from pixel at ( x1, y1 ) to pixel at ( x2, y2 );

**Note**: line colour and fill colour, for when creating shapes, are constants of this module but the module should allow for other character colours ( given by command line options or through configuration file ).

### 4.4.4. Command

#### 4.4.4.1. Attributes

N/A.

#### 4.4.4.2. Responsibilities

- ```get_input()```: asks user to input a command and continues to ask until command is valid;
- ```is_valid( letter, arguments )```: returns true if letter is a known command and number of arguments matches expected number for that command;
- ```create_canvas( width, height )```: initializes canvas, which in turn adds first layer;
- ```add_line_shape( x1, y1, x2, y2 )```: creates a new layer, if canvas has dimensions, draws a line on layer and adds layer to canvas;
- ```add_rectangle_shape( x1, y1, x2, y2 )```: creates a new layer, if canvas has dimensions, draws a rectangle on layer and adds layer to canvas;
- ```fill( x, y, colour )```: delegates to canvas.fill();
- ```show_canvas()```: delegates to canvas.repaint();
- ```reset_canvas()```: delegates to canvas.reset();
- ```execute_action( action, arguments )```: executes one the following actions and shows canvas if action successful:
    - C: delegates on create_canvas( width, height )
    - L: delegates on create_canvas( x1, y1, x2, y2 )
    - R: delegates on add_rectangle_shape( x1, y1, x2, y2 )
    - B: delegates on fill( x, y, colour )

### 4.4.5. Painter

This is the main program, which works as a REPL - Read-Eval-Print Loop:

- Read: get valid command from user, delegating on command.get_input();
- Eval: case command letter
    - C: then execute create canvas action;
    - L: then execute draw line, if canvas is initialized;
    - R: then execute draw rectangle, if canvas is initialized;
    - B: then execute bucket fill action.
- Print: if command was successful then paint canvas else output "unable to execute command!" message;
- Loop: repeat until command is quit action.
