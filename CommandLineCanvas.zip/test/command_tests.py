#!/usr/bin/env python
# -*- coding: utf-8 -*-

import unittest

import os
import sys

top_folder = os.path.dirname( sys.path[ 0 ] )
sys.path.append( os.path.join( top_folder, 'include', 'libpython' ) )

import command

uninitialized_canvas_lines = [];
layer_0_canvas_3x3_lines   = [ '-----'
                             , '|   |'
                             , '|   |'
                             , '|   |'
                             , '-----'
                             ];
layer_1_canvas_3x3_lines   = [ '-----'
                             , '|   |'
                             , '| x |'
                             , '| x |'
                             , '-----'
                             ];
layer_2_canvas_3x3_lines   = [ '-----'
                             , '|xxx|'
                             , '| x |'
                             , '| x |'
                             , '-----'
                             ];
layer_3_canvas_3x3_lines   = [ '-----'
                             , '|xxx|'
                             , '|x x|'
                             , '|xxx|'
                             , '-----'
                             ];
filled_0_canvas_3x3_lines  = [ '-----'
                             , '|ooo|'
                             , '|ooo|'
                             , '|ooo|'
                             , '-----'
                             ];
filled_1_canvas_3x3_lines  = [ '-----'
                             , '|ooo|'
                             , '|oxo|'
                             , '|oxo|'
                             , '-----'
                             ];
filled_2_canvas_3x3_lines  = [ '-----'
                             , '|xxx|'
                             , '| xo|'
                             , '| xo|'
                             , '-----'
                             ];
filled_3_canvas_3x3_lines  = [ '-----'
                             , '|xxx|'
                             , '|xox|'
                             , '|xxx|'
                             , '-----'
                             ];

class TestCases( unittest.TestCase ) :

  standard_output = None

  @classmethod
  def setUpClass( klass ) :
    global standard_output

    standard_output = sys.stdout
    sys.stdout      = open( os.devnull, 'w' )

  @classmethod
  def tearDownClass( klass ) :
    sys.stdout = standard_output

  def setUp( self ) :
    command.reset_canvas()

  def test_is_valid_command_false( self ) :
    self.assertFalse( command.is_valid( None, None ), 'is_valid( None, None ) is an unknown command' )

    self.assertFalse( command.is_valid( 'X', None                  ), 'is_valid( X, None                ) is an unknown command'                 )
    self.assertFalse( command.is_valid( 'C', [ 20, 4, 'o' ]        ), 'is_valid( C, [ 20, 4, o ]        ) is not a valid create canvas command'  )
    self.assertFalse( command.is_valid( 'C', [ 20 ]                ), 'is_valid( C, [ 20 ]              ) is not a valid create canvas command'  )
    self.assertFalse( command.is_valid( 'L', [  1, 2,  6, 2, 'o' ] ), 'is_valid( L, [  1, 2,  6, 2, o ] ) is not a valid draw line command'      )
    self.assertFalse( command.is_valid( 'L', [  1, 2 ]             ), 'is_valid( L, [  1, 2 ]           ) is not a valid draw line command'      )
    self.assertFalse( command.is_valid( 'R', [ 16, 1, 20, 3, 'o' ] ), 'is_valid( R, [ 16, 1, 20, 3, o ] ) is not a valid draw rectangle command' )
    self.assertFalse( command.is_valid( 'R', [ 16, 1 ]             ), 'is_valid( R, [ 16, 1 ]           ) is not a valid draw rectangle command' )
    self.assertFalse( command.is_valid( 'B', [ 10, 3 ]             ), 'is_valid( B, [ 10, 3 ]           ) is not a valid fill area command'      )

  def test_is_valid_command_true( self ) :
    self.assertTrue( command.is_valid( 'Q', []               ), 'is_valid( Q, []               ) is a valid quit command'           )
    self.assertTrue( command.is_valid( 'Q', None             ), 'is_valid( Q, None             ) is a valid quit command'           )
    self.assertTrue( command.is_valid( 'C', [ 20, 4 ]        ), 'is_valid( C, [ 20, 4 ]        ) is a valid create canvas command'  )
    self.assertTrue( command.is_valid( 'L', [  1, 2,  6, 2 ] ), 'is_valid( L, [  1, 2,  6, 2 ] ) is a valid draw line command'      )
    self.assertTrue( command.is_valid( 'R', [ 16, 1, 20, 3 ] ), 'is_valid( R, [ 16, 1, 20, 3 ] ) is a valid draw rectangle command' )
    self.assertTrue( command.is_valid( 'B', [ 10, 3, 'o' ]   ), 'is_valid( B, [ 10, 3, o ]     ) is a valid fill area command'      )

  def test_create_canvas_invalid( self ) :
    self.assertFalse( command.create_canvas( None, None ), 'create_canvas() with no width and height is not valid' )
    self.assertFalse( command.create_canvas( None, 100  ), 'create_canvas() with no width  is not valid'           )
    self.assertFalse( command.create_canvas( 200 , None ), 'create_canvas() with no height is not valid'           )

    self.assertFalse( command.create_canvas(   0, 100 ), 'create_canvas() with width = 0  is not valid' )
    self.assertFalse( command.create_canvas( 200,   0 ), 'create_canvas() with height = 0 is not valid' )

  def test_create_canvas_valid( self ) :
    self.assertTrue( command.create_canvas( 20  , 10   ), 'create_canvas() with positive width and height numbers is valid' )
    self.assertTrue( command.create_canvas( '20', '10' ), 'create_canvas() with positive width and height strings is valid' )

  def test_show_canvas_when_uninitialized( self ) :
    self.assertListEqual( command.show_canvas(), uninitialized_canvas_lines, 'show_canvas() of an uninitialized canvas returns no output lines' )

  def test_show_canvas_when_initialized( self ) :
    command.create_canvas( 3, 3 )
    self.assertListEqual( command.show_canvas(), layer_0_canvas_3x3_lines, 'show_canvas() of an initialized canvas returns initialized layer' )

  def test_add_line_shape_when_uninitialized( self ) :
    self.assertFalse( command.add_line_shape( 2, 2, 2, 3 ), 'add_line_shape() to an uninitialized canvas returns False' )

  def test_add_line_shape_when_initialized( self ) :
    command.create_canvas( 3, 3 )
    self.assertTrue( command.add_line_shape( 2, 2, 2, 3 ), 'add_line_shape() to an initialized canvas returns True' )
    self.assertTrue( command.add_line_shape( '2', '2', '2', '3' ), 'add_line_shape() to an initialized canvas returns True' )

  def test_add_line_shapes( self ) :
    command.create_canvas( 3, 3 )
    command.add_line_shape( 2, 2, 2, 3 )
    self.assertListEqual( command.show_canvas(), layer_1_canvas_3x3_lines, 'add_line_shape() draws vertical lines' )
    command.add_line_shape( 1, 1, 3, 1 )
    self.assertListEqual( command.show_canvas(), layer_2_canvas_3x3_lines, 'add_line_shape() draws vertical lines' )

  def test_add_rectangle_shape_when_uninitialized( self ) :
    self.assertFalse( command.add_rectangle_shape( 1, 1, 3, 3 ), 'add_rectangle_shape() to an uninitialized canvas returns False' )

  def test_add_rectangle_shape_when_initialized( self ) :
    command.create_canvas( 3, 3 )
    self.assertTrue( command.add_rectangle_shape( 1, 1, 3, 3 ), 'add_rectangle_shape() to an initialized canvas returns True' )
    self.assertTrue( command.add_rectangle_shape( '1', '1', '3', '3' ), 'add_rectangle_shape() to an initialized canvas returns True' )

  def test_add_rectangle_shape( self ) :
    command.create_canvas( 3, 3 )
    command.add_rectangle_shape( 1, 1, 3, 3 )
    self.assertListEqual( command.show_canvas(), layer_3_canvas_3x3_lines, 'add_rectangle_shape() draws rectangles' )

  def test_fill_when_uninitialized( self ) :
    command.fill( 1, 1, 'o' )
    self.assertListEqual( command.show_canvas(), uninitialized_canvas_lines, 'fill() of an uninitialized canvas does nothing' )

  def test_fill_when_initialized( self ) :
    command.create_canvas( 3, 3 )
    command.fill( 1, 1, 'o' )
    self.assertListEqual( command.show_canvas(), filled_0_canvas_3x3_lines, 'fill() of an initialized canvas fills the entire layer' )
    command.fill( '1', '1', '' )
    self.assertListEqual( command.show_canvas(), layer_0_canvas_3x3_lines, 'fill() can also fill an entire layer with transparent colour' )

  def test_layer_1_fill( self ) :
    command.create_canvas( 3, 3 )
    command.add_line_shape( 2, 2, 2, 3 )
    command.fill( 2, 2, 'o' )
    self.assertListEqual( command.show_canvas(), layer_1_canvas_3x3_lines, 'fill() at a pixel with line colour does not change layers' )
    command.fill( 1, 1, 'o' )
    self.assertListEqual( command.show_canvas(), filled_1_canvas_3x3_lines, 'fill() at a pixel with any background colour changes layer' )

  def test_layer_2_fill( self ) :
    command.create_canvas( 3, 3 )
    command.add_line_shape( 2, 2, 2, 3 )
    command.add_line_shape( 1, 1, 3, 1 )
    command.fill( 2, 2, 'o' )
    self.assertListEqual( command.show_canvas(), layer_2_canvas_3x3_lines, 'fill() at a pixel with line colour does not change layers' )
    command.fill( 3, 3, 'o' )
    self.assertListEqual( command.show_canvas(), filled_2_canvas_3x3_lines, 'fill() at a pixel with any background colour changes layer' )

  def test_layer_3_fill( self ) :
    command.create_canvas( 3, 3 )
    command.add_line_shape( 2, 2, 2, 3 )
    command.add_line_shape( 1, 1, 3, 1 )
    command.add_rectangle_shape( 1, 1, 3, 3 )
    command.fill( 3, 3, 'o' )
    self.assertListEqual( command.show_canvas(), layer_3_canvas_3x3_lines, 'fill() at a pixel with line colour does not change layers' )
    command.fill( 2, 2, 'o' )
    self.assertListEqual( command.show_canvas(), filled_3_canvas_3x3_lines, 'fill() at a pixel with any background colour changes layer' )

  def test_execute_action( self ) :
    self.assertTrue( command.execute_action( 'Q', None ), 'execute_action( Q, None ) is always successful' )
    self.assertTrue( command.execute_action( 'Q', []   ), 'execute_action( Q, []   ) is always successful' )
    
    self.assertFalse( command.execute_action( 'Z', None ), 'execute_action( Z, None ) is unsuccessfu' )
    
    self.assertFalse( command.execute_action( 'L', [  1, 2,  6, 2 ] ), 'execute_action( L, [  1, 2,  6, 2 ] ) fails when canvas is uninitialized' )
    self.assertFalse( command.execute_action( 'R', [ 16, 1, 20, 3 ] ), 'execute_action( R, [ 16, 1, 20, 3 ] ) fails when canvas is uninitialized' )
    self.assertFalse( command.execute_action( 'B', [ 10, 3, 'o' ]   ), 'execute_action( B, [ 10, 3, o ]     ) fails when canvas is uninitialized' )

    self.assertTrue( command.execute_action( 'c', [ 20, 4 ]        ), 'execute_action( c, [ 20, 4 ]        ) is successful' )
    self.assertTrue( command.execute_action( 'l', [  1, 2,  6, 2 ] ), 'execute_action( l, [  1, 2,  6, 2 ] ) is successful, after canvas is initialized' )
    self.assertTrue( command.execute_action( 'r', [ 16, 1, 20, 3 ] ), 'execute_action( r, [ 16, 1, 20, 3 ] ) is successful, after canvas is initialized' )
    self.assertTrue( command.execute_action( 'b', [ 10, 3, 'o' ]   ), 'execute_action( b, [ 10, 3, o ]     ) is successful, after canvas is initialized' )
    self.assertTrue( command.execute_action( 'q', []               ), 'execute_action( q, []               ) is successful, after canvas is initialized' )
    self.assertTrue( command.execute_action( 'q', None             ), 'execute_action( q, None             ) is successful, after canvas is initialized' )

if __name__ == '__main__' :

  unittest.main()
