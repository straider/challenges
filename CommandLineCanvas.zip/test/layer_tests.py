#!/usr/bin/env python
# -*- coding: utf-8 -*-

import unittest

import os
import sys

top_folder = os.path.dirname( sys.path[ 0 ] )
sys.path.append( os.path.join( top_folder, 'include', 'libpython' ) )

import layer

layer_3x3_rows    = [ [ '-', '-', '-', '-', '-' ]
                    , [ '|', '' , '' , '' , '|' ]
                    , [ '|', '' , '' , '' , '|' ]
                    , [ '|', '' , '' , '' , '|' ]
                    , [ '-', '-', '-', '-', '-' ]
                    ];
lower_3x3_rows    = [ [ '-', '-', '-', '-', '-' ]
                    , [ '|', 'o', 'o', 'o', '|' ]
                    , [ '|', 'o', 'o', 'o', '|' ]
                    , [ '|', 'o', 'o', 'o', '|' ]
                    , [ '-', '-', '-', '-', '-' ]
                    ];
upper_3x3_rows    = [ [ '-', '-', '-', '-', '-' ]
                    , [ '|', '' , 'x', '' , '|' ]
                    , [ '|', '' , 'x', '' , '|' ]
                    , [ '|', '' , '' , '' , '|' ]
                    , [ '-', '-', '-', '-', '-' ]
                    ];
merged_3x3_rows   = [ [ '-', '-', '-', '-', '-' ]
                    , [ '|', 'o', 'x', 'o', '|' ]
                    , [ '|', 'o', 'x', 'o', '|' ]
                    , [ '|', 'o', 'o', 'o', '|' ]
                    , [ '-', '-', '-', '-', '-' ]
                    ];
marked_3x3_rows   = [ [ '-', '-', '-', '-', '-' ]
                    , [ '|', 'o', 'x', 'o', '|' ]
                    , [ '|', 'o', 'x', 'o', '|' ]
                    , [ '|', 'o', 'c', 'o', '|' ]
                    , [ '-', '-', '-', '-', '-' ]
                    ];

original_3x3_rows = [ [ '-', '-', '-', '-', '-' ]
                    , [ '|', '' , 'x', '' , '|' ]
                    , [ '|', '' , 'x', '' , '|' ]
                    , [ '|', '' , 'x', '' , '|' ]
                    , [ '-', '-', '-', '-', '-' ]
                    ];
changed_3x3_rows  = [ [ '-', '-', '-', '-', '-' ]
                    , [ '|', 'o', 'x', 'o', '|' ]
                    , [ '|', 'o', 'x', 'o', '|' ]
                    , [ '|', 'o', 'x', 'o', '|' ]
                    , [ '-', '-', '-', '-', '-' ]
                    ];

original_3x5_rows = [ [ '-', '-', '-', '-', '-' ]
                    , [ '|', 'A', 'A', '' , '|' ]
                    , [ '|', 'A', 'x', '' , '|' ]
                    , [ '|', 'A', '' , '' , '|' ]
                    , [ '|', 'A', '' , 'B', '|' ]
                    , [ '|', 'A', '' , 'B', '|' ]
                    , [ '-', '-', '-', '-', '-' ]
                    ];
changed_3x5_rows  = [ [ '-', '-', '-', '-', '-' ]
                    , [ '|', 'C', 'C', '' , '|' ]
                    , [ '|', 'C', 'x', '' , '|' ]
                    , [ '|', 'C', '' , '' , '|' ]
                    , [ '|', 'C', '' , 'B', '|' ]
                    , [ '|', 'C', '' , 'B', '|' ]
                    , [ '-', '-', '-', '-', '-' ]
                    ];

none_layer_lines = [];
layer_3x3_lines  = [ '-----'
                   , '|   |'
                   , '|   |'
                   , '|   |'
                   , '-----'
                   ];
merged_3x3_lines = [ '-----'
                   , '|oxo|'
                   , '|oxo|'
                   , '|ooo|'
                   , '-----'
                   ];

pixels_colour_x  = [ ( 2, 1 ), ( 2, 2 ) ]
pixels_colour_o  = [ ( 1, 1 ), ( 1, 2 ), ( 1, 3 ), ( 2, 3 ), ( 3, 1 ), ( 3, 2 ), ( 3, 3 ) ]
pixels_colour_o1 = [ ( 1, 1 ), ( 1, 2 ), ( 1, 3 ) ]
pixels_colour_o2 = [ ( 3, 1 ), ( 3, 2 ), ( 3, 3 ) ]

class TestCases( unittest.TestCase ) :

  def test_create_layer_invalid( self ) :
    self.assertIsNone( layer.create( None, None ), 'create() with no width and height is not valid' )
    self.assertIsNone( layer.create( None, 100  ), 'create() with no width  is not valid'           )
    self.assertIsNone( layer.create( 200 , None ), 'create() with no height is not valid'           )

    self.assertIsNone( layer.create(   0, 100 ), 'create() with width = 0  is not valid' )
    self.assertIsNone( layer.create( 200,   0 ), 'create() with height = 0 is not valid' )

  def test_create_layer_valid( self ) :
    new_layer = layer.create( 3, 3 )
    self.assertListEqual( new_layer, layer_3x3_rows, 'create() creates rows with margins and filled with transparent colour' )

  def test_paint_layer_none( self ) :
    self.assertListEqual( layer.paint( None ), none_layer_lines, 'paint() of an uninitialized layer returns no output lines' )

  def test_paint_created_layer( self ) :
    new_layer = layer.create( 3, 3 )
    self.assertListEqual( layer.paint( new_layer ), layer_3x3_lines, 'paint() of an initialized layer returns row lines' )

  def test_merge_layers( self ) :
    self.assertListEqual( layer.merge( lower_3x3_rows, upper_3x3_rows ), merged_3x3_rows, 'merge() rows of lower layer with rows of upper layer' )

  def test_paint_merged_layers( self ) :
    merged_layer = layer.merge( lower_3x3_rows, upper_3x3_rows )
    self.assertListEqual( layer.paint( merged_layer ), merged_3x3_lines, 'paint() of an merged layer returns row lines' )

  def test_get_colour_invalid( self ) :
    self.assertIsNone( layer.get_colour( None, 1, 1 ), 'get_colour() in a layer without dimensions is not valid' )

    self.assertIsNone( layer.get_colour( original_3x5_rows, -1, -1 ), 'get_colour() below layer dimensions is not valid' )
    self.assertIsNone( layer.get_colour( original_3x5_rows,  5,  5 ), 'get_colour() above layer dimensions is not valid' )

  def test_get_colour_valid( self ) :
    self.assertEquals( layer.get_colour( merged_3x3_rows, 0, 0 ), '-', 'get_colour() at ( 0, 0 ) is valid' )
    self.assertEquals( layer.get_colour( merged_3x3_rows, 4, 0 ), '-', 'get_colour() at ( 4, 0 ) is valid' )
    self.assertEquals( layer.get_colour( merged_3x3_rows, 0, 4 ), '-', 'get_colour() at ( 0, 4 ) is valid' )
    self.assertEquals( layer.get_colour( merged_3x3_rows, 4, 4 ), '-', 'get_colour() at ( 4, 4 ) is valid' )
    self.assertEquals( layer.get_colour( merged_3x3_rows, 0, 1 ), '|', 'get_colour() at ( 0, 1 ) is valid' )
    self.assertEquals( layer.get_colour( merged_3x3_rows, 4, 1 ), '|', 'get_colour() at ( 4, 1 ) is valid' )
    self.assertEquals( layer.get_colour( merged_3x3_rows, 1, 1 ), 'o', 'get_colour() at ( 1, 1 ) is valid' )
    self.assertEquals( layer.get_colour( merged_3x3_rows, 2, 1 ), 'x', 'get_colour() at ( 2, 1 ) is valid' )
    self.assertEquals( layer.get_colour( merged_3x3_rows, 3, 1 ), 'o', 'get_colour() at ( 3, 1 ) is valid' )

  def test_is_foreground_colour( self ) :
    self.assertFalse( layer.is_foreground_colour( None ), 'is_foreground_colour() is false if colour is undefined' )

    self.assertFalse( layer.is_foreground_colour( layer.TRANSPARENT_COLOUR ), 'is_foreground_colour() is false if colour is transparent' )
    self.assertFalse( layer.is_foreground_colour( layer.BACKGROUND_COLOUR  ), 'is_foreground_colour() is false if colour is solid'       )

    self.assertTrue( layer.is_foreground_colour( layer.FOREGROUND_COLOUR ), 'is_foreground_colour() is true if colour matches line colour' )

  def test_mark_pixel_invalid( self ) :
    marked_layer = layer.mark_pixel( None, 1, 1, 'c' )
    self.assertIsNone( marked_layer, 'mark_pixel() returns same layer when layer is invalid' )
    marked_layer = layer.mark_pixel( list(), 1, 1, 'c' )
    self.assertIsNone( marked_layer, 'mark_pixel() returns same layer when layer is empty' )

    marked_layer = layer.mark_pixel( merged_3x3_rows, None, None, 'c' )
    self.assertListEqual( marked_layer, merged_3x3_rows, 'mark_pixel() returns same layer when pixel is invalid' )
    marked_layer = layer.mark_pixel( merged_3x3_rows, 1, 1, None )
    self.assertListEqual( marked_layer, merged_3x3_rows, 'mark_pixel() returns same layer when colour is invalid' )
    marked_layer = layer.mark_pixel( merged_3x3_rows, 3, 0, 'c' )
    self.assertListEqual( marked_layer, merged_3x3_rows, 'mark_pixel() returns same layer when pixel is at top margin' )
    marked_layer = layer.mark_pixel( merged_3x3_rows, 3, 4, 'c' )
    self.assertListEqual( marked_layer, merged_3x3_rows, 'mark_pixel() returns same layer when pixel is at bottom margin' )
    marked_layer = layer.mark_pixel( merged_3x3_rows, 0, 1, 'c' )
    self.assertListEqual( marked_layer, merged_3x3_rows, 'mark_pixel() returns same layer when pixel is at left margin' )
    marked_layer = layer.mark_pixel( merged_3x3_rows, 4, 1, 'c' )
    self.assertListEqual( marked_layer, merged_3x3_rows, 'mark_pixel() returns same layer when pixel is at right margin' )

  def test_mark_pixel_valid( self ) :
    marked_layer = layer.mark_pixel( merged_3x3_rows, 2, 3, 'c' )
    self.assertListEqual( marked_layer, marked_3x3_rows, 'mark_pixel() changes pixel colour' )

  def test_collect_pixels_empty( self ) :
    pixels = layer.collect_pixels( None, 1, 1, 'c' )
    self.assertIsNone( pixels, 'collect_pixels() returns none when layer is invalid' )
    pixels = layer.collect_pixels( list(), 1, 1, 'c' )
    self.assertIsNone( pixels, 'collect_pixels() returns none when layer is empty' )

    pixels = layer.collect_pixels( merged_3x3_rows, None, None, 'c' )
    self.assertIsNone( pixels, 'collect_pixels() returns none when pixel is invalid' )
    pixels = layer.collect_pixels( merged_3x3_rows, 1, 1, None )
    self.assertIsNone( pixels, 'collect_pixels() returns none when colour is invalid' )
    pixels = layer.collect_pixels( merged_3x3_rows, 3, 0, 'c' )
    self.assertIsNone( pixels, 'collect_pixels() returns none when pixel is at top margin' )
    pixels = layer.collect_pixels( merged_3x3_rows, 3, 4, 'c' )
    self.assertIsNone( pixels, 'collect_pixels() returns none when pixel is at bottom margin' )
    pixels = layer.collect_pixels( merged_3x3_rows, 0, 1, 'c' )
    self.assertIsNone( pixels, 'collect_pixels() returns none when pixel is at left margin' )
    pixels = layer.collect_pixels( merged_3x3_rows, 4, 1, 'c' )
    self.assertIsNone( pixels, 'collect_pixels() returns none when pixel is at right margin' )

    pixels = layer.collect_pixels( merged_3x3_rows, 1, 1, 'c' )
    self.assertListEqual( pixels, list(), 'collect_pixels() returns empty list of pixels when pixel has different colour' )

  def test_collect_pixels_list( self ) :
    pixels = layer.collect_pixels( merged_3x3_rows, 2, 1, 'x' )
    self.assertListEqual( pixels, pixels_colour_x, 'collect_pixels() returns list of pixels having colour x' )
    pixels = layer.collect_pixels( merged_3x3_rows, 1, 1, 'o' )
    self.assertListEqual( pixels, pixels_colour_o, 'collect_pixels() returns list of pixels having colour o' )
    pixels = layer.collect_pixels( marked_3x3_rows, 1, 1, 'o' )
    self.assertListEqual( pixels, pixels_colour_o1, 'collect_pixels() returns list of pixels having colour o on the left side' )
    pixels = layer.collect_pixels( marked_3x3_rows, 3, 3, 'o' )
    self.assertListEqual( pixels, pixels_colour_o2, 'collect_pixels() returns list of pixels having colour o on the right side' )

if __name__ == '__main__' :

  unittest.main()
