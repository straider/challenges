#!/usr/bin/env python
# -*- coding: utf-8 -*-

import unittest

import os
import sys

top_folder = os.path.dirname( sys.path[ 0 ] )
sys.path.append( os.path.join( top_folder, 'include', 'libpython' ) )

import layer
import shape

horizontal_3x3_rows = [ [ '-', '-', '-', '-', '-' ]
                      , [ '|', '' , '' , '' , '|' ]
                      , [ '|', 'x', 'x', 'x', '|' ]
                      , [ '|', '' , '' , '' , '|' ]
                      , [ '-', '-', '-', '-', '-' ]
                      ];
vertical_3x3_rows   = [ [ '-', '-', '-', '-', '-' ]
                      , [ '|', '' , 'x', '' , '|' ]
                      , [ '|', '' , 'x', '' , '|' ]
                      , [ '|', '' , 'x', '' , '|' ]
                      , [ '-', '-', '-', '-', '-' ]
                      ];
square_3x3_rows     = [ [ '-', '-', '-', '-', '-' ]
                      , [ '|', 'x', 'x', 'x', '|' ]
                      , [ '|', 'x', ' ', 'x', '|' ]
                      , [ '|', 'x', 'x', 'x', '|' ]
                      , [ '-', '-', '-', '-', '-' ]
                      ];

class TestCases( unittest.TestCase ) :

  def test_is_line_horizontal( self ) :
    self.assertFalse( shape.is_line_horizontal( None, None, None, None ), 'is_line_horizontal() is false when points are invalid' )

    self.assertFalse( shape.is_line_horizontal(  0, 0,  0, 0 ), 'is_line_horizontal() is false when points are zero'        )
    self.assertFalse( shape.is_line_horizontal( 10, 4, 15, 6 ), 'is_line_horizontal() is false when y1 does not matches y2' )

    self.assertTrue( shape.is_line_horizontal( 10, 4, 15, 4 ), 'is_line_horizontal() is true when y1 matches y2' )

  def test_is_line_vertical( self ) :
    self.assertFalse( shape.is_line_vertical( None, None, None, None ), 'is_line_vertical() is false when points are invalid' )

    self.assertFalse( shape.is_line_vertical(  0, 0,  0, 0 ), 'is_line_vertical() is false when points are zero'        )
    self.assertFalse( shape.is_line_vertical( 10, 4, 15, 6 ), 'is_line_vertical() is false when x1 does not matches x2' )

    self.assertTrue( shape.is_line_vertical( 15, 4, 15, 6 ), 'is_line_vertical() is true when x1 matches x2' )

  def test_draw_line_without_layer( self ) :
    self.assertIsNone( shape.draw_line( None, 1, 1, 1, 1 ), 'draw_line() does not change layer if layer is invalid' )

  def test_draw_rectangle_without_layer( self ) :
    self.assertIsNone( shape.draw_rectangle( None, 1, 1, 1, 1 ), 'draw_rectangle() does not change layer if layer is invalid' )

  def test_draw_line_invalid( self ) :
    clean_layer = layer.create( 3, 3 )
    drawn_layer = shape.draw_line( clean_layer, None, None, None, None )
    self.assertListEqual( drawn_layer, clean_layer, 'draw_line() does not change layer if line points are invalid' )
    drawn_layer = shape.draw_line( clean_layer, 0, 1, 4, 1 )
    self.assertListEqual( drawn_layer, clean_layer, 'draw_line() does not change layer if line starts at left margin' )
    drawn_layer = shape.draw_line( clean_layer, 1, 1, 5, 1 )
    self.assertListEqual( drawn_layer, clean_layer, 'draw_line() does not change layer if line ends at right margin' )
    drawn_layer = shape.draw_line( clean_layer, 1, 0, 1, 4 )
    self.assertListEqual( drawn_layer, clean_layer, 'draw_line() does not change layer if line start at top margin' )
    drawn_layer = shape.draw_line( clean_layer, 1, 2, 1, 5 )
    self.assertListEqual( drawn_layer, clean_layer, 'draw_line() does not change layer if line ends at bottom margin' )
    drawn_layer = shape.draw_line( clean_layer, 1, 2, 3, 4 )
    self.assertListEqual( drawn_layer, clean_layer, 'draw_line() does not change layer if line is not horizontal or vertical' )

  def test_draw_line_horizontal( self ) :
    clean_layer = layer.create( 3, 3 )
    drawn_layer = shape.draw_line( clean_layer, 1, 2, 3, 2 )
    self.assertListEqual( drawn_layer, horizontal_3x3_rows, 'draw_line() draws horizontal lines' )

  def test_draw_line_vertical( self ) :
    clean_layer = layer.create( 3, 3 )
    drawn_layer = shape.draw_line( clean_layer, 2, 1, 2, 3 )
    self.assertListEqual( drawn_layer, vertical_3x3_rows, 'draw_line() draws vertical lines' )

  def test_draw_rectangle( self ) :
    clean_layer = layer.create( 3, 3 )
    drawn_layer = shape.draw_rectangle( clean_layer, 1, 1, 3, 3 )
    self.assertListEqual( drawn_layer, square_3x3_rows, 'draw_rectangle() draws rectangle filled with solid colour' )

if __name__ == '__main__' :

  unittest.main()
