#!/usr/bin/env python
# -*- coding: utf-8 -*-

import unittest

import os
import sys

top_folder = os.path.dirname( sys.path[ 0 ] )
sys.path.append( os.path.join( top_folder, 'include', 'libpython' ) )

import canvas

layer_1_3x3_rows = [ [ '-', '-', '-', '-', '-' ]
                   , [ '|', '' , '' , '' , '|' ]
                   , [ '|', '' , 'x', '' , '|' ]
                   , [ '|', '' , '' , '' , '|' ]
                   , [ '-', '-', '-', '-', '-' ]
                   ];
layer_2_3x3_rows = [ [ '-', '-', '-', '-', '-' ]
                   , [ '|', 'x', 'x', 'x', '|' ]
                   , [ '|', '' , '' , '' , '|' ]
                   , [ '|', 'x', 'x', 'x', '|' ]
                   , [ '-', '-', '-', '-', '-' ]
                   ];

uninitialized_canvas_lines    = [];
initialized_canvas_3x1_lines  = [ '-----'
                                , '|   |'
                                , '-----'
                                ];
filled_once_canvas_3x1_lines  = [ '-----'
                                , '|111|'
                                , '-----'
                                ];
filled_twice_canvas_3x1_lines = [ '-----'
                                , '|222|'
                                , '-----'
                                ];
filled_0_canvas_3x3_lines     = [ '-----'
                                , '|ooo|'
                                , '|ooo|'
                                , '|ooo|'
                                , '-----'
                                ];
unfilled_1_canvas_3x3_lines   = [ '-----'
                                , '|   |'
                                , '| x |'
                                , '|   |'
                                , '-----'
                                ];
filled_1_canvas_3x3_lines     = [ '-----'
                                , '|ooo|'
                                , '|oxo|'
                                , '|ooo|'
                                , '-----'
                                ];
unfilled_2_canvas_3x3_lines   = [ '-----'
                                , '|xxx|'
                                , '| x |'
                                , '|xxx|'
                                , '-----'
                                ];
filled_2_canvas_3x3_lines     = [ '-----'
                                , '|xxx|'
                                , '|ox |'
                                , '|xxx|'
                                , '-----'
                                ];
filled_3_canvas_3x3_lines     = [ '-----'
                                , '|xxx|'
                                , '|oxo|'
                                , '|xxx|'
                                , '-----'
                                ];
filled_4_canvas_3x3_lines     = [ '-----'
                                , '|xxx|'
                                , '|oxc|'
                                , '|xxx|'
                                , '-----'
                                ];

class TestCases( unittest.TestCase ) :

  standard_output = None

  @classmethod
  def setUpClass( klass ) :
    global standard_output

    standard_output = sys.stdout
    sys.stdout      = open( os.devnull, 'w' )

  @classmethod
  def tearDownClass( klass ) :
    sys.stdout = standard_output

  def setUp( self ) :
    canvas.reset()

  def test_is_initialized_false( self ) :
    self.assertFalse( canvas.is_initialized(), 'is_initialized() is false when canvas is uninitialized' )

  def test_is_initialized_true( self ) :
    canvas.initialize( 200, 100 )
    self.assertTrue( canvas.is_initialized(), 'is_initialized() is true when canvas is initialized' )

  def test_uninitialize_canvas( self ) :
    self.assertIsNone( canvas.width , 'uninitialize canvas has no width'  )
    self.assertIsNone( canvas.height, 'uninitialize canvas has no height' )
    self.assertEqual( len( canvas.layers ), 0, 'uninitialize canvas has no layers' )

  def test_create_canvas_invalid( self ) :
    self.assertFalse( canvas.initialize( None, None ), 'initialize() with no width and height is not valid' )
    self.assertFalse( canvas.initialize( None, 100  ), 'initialize() with no width  is not valid'           )
    self.assertFalse( canvas.initialize( 200 , None ), 'initialize() with no height is not valid'           )

    self.assertFalse( canvas.initialize(   0, 100 ), 'initialize() with width = 0  is not valid' )
    self.assertFalse( canvas.initialize( 200,   0 ), 'initialize() with height = 0 is not valid' )

  def test_create_canvas_valid( self ) :
    self.assertTrue( canvas.initialize( 200, 100 ), 'initialize() with positive width and height is valid' )

    self.assertEqual( canvas.width , 200, 'initialize canvas has width'  )
    self.assertEqual( canvas.height, 100, 'initialize canvas has height' )
    self.assertEqual( len( canvas.layers ), 1, 'initialize canvas has one layer' )

  def test_add_layer_to_canvas_invalid( self ) :
    self.assertFalse( canvas.add_layer( None ), 'add_layer() to an uninitialized canvas is not valid' )

  def test_add_layer_to_canvas( self ) :
    canvas.initialize( 200, 100 )
    self.assertTrue( canvas.add_layer( None ), 'add_layer() always adds new layer to an initialized canvas'       )
    self.assertEqual( len( canvas.layers ), 2, 'add_layer() increments number of layers in an initialized canvas' )

  def test_repaint_uninitialized_canvas( self ) :
    self.assertListEqual( canvas.repaint(), uninitialized_canvas_lines, 'repaint() of an uninitialized canvas returns no output lines' )

  def test_repaint_initialized_canvas( self ) :
    canvas.initialize( 3, 1 )
    self.assertListEqual( canvas.repaint(), initialized_canvas_3x1_lines, 'repaint() of an initialized canvas returns initialized layer' )

  def test_fill_uninitialized_canvas( self ) :
    canvas.fill( 3, 3, 'o' )
    self.assertListEqual( canvas.layers, uninitialized_canvas_lines, 'fill() of an uninitialized canvas does nothing' )

  def test_fill_initialized_canvas( self ) :
    canvas.initialize( 3, 3 )
    canvas.fill( 3, 3, 'o' )
    self.assertListEqual( canvas.repaint(), filled_0_canvas_3x3_lines, 'fill() of an initialized canvas fills the entire layer' )

  def test_fill_multiple_times_on_initialized_canvas( self ) :
    canvas.initialize( 3, 1 )
    canvas.fill( 1, 1, '1' )
    self.assertListEqual( canvas.repaint(), filled_once_canvas_3x1_lines, 'fill() once an initialized canvas' )
    canvas.fill( 1, 1, '2' ), len( canvas.layers )
    self.assertListEqual( canvas.repaint(), filled_twice_canvas_3x1_lines, 'fill() twice an initialized canvas' )
    canvas.fill( 1, 1, '' ), len( canvas.layers )
    self.assertListEqual( canvas.repaint(), initialized_canvas_3x1_lines, 'fill() can also fill an entire layer with transparent colour' )

  def test_fill_canvas_having_2_layers( self ) :
    canvas.initialize( 3, 3 )
    canvas.add_layer( layer_1_3x3_rows )
    canvas.fill( 2, 2, 'o' )
    self.assertListEqual( canvas.repaint(), unfilled_1_canvas_3x3_lines, 'fill() at a pixel with line colour does not change layers' )
    canvas.fill( 1, 1, 'o' )
    self.assertListEqual( canvas.repaint(), filled_1_canvas_3x3_lines, 'fill() at a pixel with any background colour changes layer' )

  def test_fill_canvas_having_3_layers( self ) :
    canvas.initialize( 3, 3 )
    canvas.add_layer( layer_1_3x3_rows )
    canvas.add_layer( layer_2_3x3_rows )
    canvas.fill( 2, 2, '1' )
    self.assertListEqual( canvas.repaint(), unfilled_2_canvas_3x3_lines, 'fill() at a pixel with line colour does not change layers' )

    canvas.initialize( 3, 3 )
    canvas.add_layer( layer_1_3x3_rows )
    canvas.add_layer( layer_2_3x3_rows )
    canvas.fill( 1, 2, 'o' )
    self.assertListEqual( canvas.repaint(), filled_2_canvas_3x3_lines, 'fill() does not spill for transparent colour' )
    canvas.fill( 3, 2, 'o' )
    self.assertListEqual( canvas.repaint(), filled_3_canvas_3x3_lines, 'fill() does not spill for background colour' )
    canvas.fill( 3, 2, 'c' )
    self.assertListEqual( canvas.repaint(), filled_4_canvas_3x3_lines, 'fill() does not swap colours' )

if __name__ == '__main__' :

  unittest.main()
